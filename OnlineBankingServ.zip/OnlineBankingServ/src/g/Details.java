package g;
// THIS PROGRAM GBANK IS THE INTERFACE FOR THE MAIN PROGRAM

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Details extends Remote {
	public int open(String username, String password, double amount, String adderess, double phone)
			throws RemoteException;

	public String balance(int acno, String uname, String pass) throws RemoteException;
}